TCMTS Dataset Documentation

This document specifies the full TCMTS dataset and the deduplicated modeling subset named data for single compound–target interaction studies.

0) Files in the repo (suggested)
data/
├─ TCMTS.csv           # full, non-deduplicated dataset (13 columns, see §1)
├─ data.csv            # deduplicated modeling subset (4 columns, see §3.2)
└─ TCMTS.md            # this document

1) Full TCMTS schema (13 columns)

Recommended headers use snake_case. Keep UTF-8 encoding.

#	Column name (suggested)	Type	Description
1	record_id	Integer	Internal index of the compiled dataset (row ID).
2	herb_name_zh	String	Chinese common name of the herb.
3	herb_name_en	String	English name of the herb.
4	family_zh	String	Chinese name of the botanical family.
5	family_en	String	English name of the botanical family.
6	genus_zh	String	Chinese name of the botanical genus.
7	genus_en	String	English name of the botanical genus.
8	tcmsP_mol_id	String	TCMSP Mol ID of a chemical ingredient contained in the herb. Use this ID to retrieve SMILES and other metadata from TCMSP.
9	pubchem_cid	String	PubChem CID for the ingredient. Use it to access records at https://pubchem.ncbi.nlm.nih.gov
.
10	molecule_name	String	Ingredient (molecule) name corresponding to the Mol ID in column 8.
11	uniprot_id	String	UniProt ID of a target protein that interacts with the ingredient (column 8). Use it to fetch sequence/annotations at https://www.uniprot.org/
.
12	target_name	String	Target protein name corresponding to column 11.
13	diseases	String (comma-separated)	Disease indications associated with the target (column 11). Multiple diseases stored in one field, separated by commas.

Note. Multiple herbs can contain the same ingredient, so identical (ingredient, target) pairs may appear in multiple rows (one per herb source).

2) External resources

TCMSP: use tcmsP_mol_id to pull SMILES and other chemical metadata.

PubChem: https://pubchem.ncbi.nlm.nih.gov/compound/<pubchem_cid>

UniProt: https://www.uniprot.org/uniprotkb/<uniprot_id>/entry

3) Modeling subset: data (deduplicated)
3.1 Rationale

For western-drug-style analyses where the atomic instance is one ingredient ↔ one target, deduplicate TCMTS to unique (ingredient, target) pairs regardless of how many herbs contain that ingredient.

3.2 data.csv schema (4 columns)
#	Column name (fixed)	Type	Description
1	tcmsP_mol_id	String	Ingredient identifier (TCMSP Mol ID).
2	smiles	String	Canonical SMILES of the ingredient (resolved via TCMSP or PubChem).
3	uniprot_id	String	Target identifier (UniProt ID).
4	sequence	String	Amino-acid sequence of the target (from UniProt).

You can always map back from data.csv to the full TCMTS by searching rows with the same tcmsP_mol_id to recover the herb provenance.
